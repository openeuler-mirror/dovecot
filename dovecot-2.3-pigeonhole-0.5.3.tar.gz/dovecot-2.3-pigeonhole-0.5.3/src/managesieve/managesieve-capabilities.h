#ifndef MANAGESIEVE_CAPABILITIES_H
#define MANAGESIEVE_CAPABILITIES_H

void managesieve_capabilities_dump(void);

#endif
